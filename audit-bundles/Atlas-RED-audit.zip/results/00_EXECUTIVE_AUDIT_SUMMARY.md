# ATLAS RED independent audit — executive summary

## Verdict

**AUDIT INCOMPLETE.** The pinned S49 repository is **not release-ready** for the full owner target, sustained full-breadth collection, agent selection, assisted execution, or capital. The current system keeps live capital, assisted execution, and the discretionary agent disabled. Positive after-cost trading value is **NOT ESTIMABLE**.

The six Luna-requested reviewer reports and required trader cross-reviews are assembled from the same pinned code tree. The owner waived two missing source documents, leaving 22/24 source-document coverage. T1/T3/E1/E2/E3 reported full reads of the 22 available documents; T2 disclosed that output truncation prevented it from confirming a full read, even in a 150-line runbook chunk. Model identity/start-order metadata was not returned, external research pages were blocked by the public documentation tunnel, and full deep review of every code symbol is not complete. Those are explicit audit limits, not claims Atlas passed.

The audit remained read-only. No Atlas code/config/dependency/test/branch, trading credentials, orders, exchange endpoints, or external AI-provider calls were changed or used. No tests were run. Reports and the generated static inventory are outside the checkout under `/tmp/atlas_readonly_audit_a73c92d83ca8/results/`.

## Readiness snapshot

| Area | Verdict | Evidence |
|---|---|---|
| Pinned code | `a73c92d83ca8b2fe5163e636b2c9732361b35e23`, clean detached audit tree | S49 final HEAD is present. The handoff’s stated implementation SHA `00ed85fb61c0941f045472319aa19b795577168e` is not in the Git graph; parent is `00ed85f9dae78b29989e442dfb0d70576671ff48`. |
| Product integration | `TEST GATE` | The deterministic research flow reaches candidate selection, risk, economics, calendar and restart; production records `agent_mode=DISABLED`. Decision Brief/ResearchAgent/memory are not connected as a production chooser. |
| Source workload | `TEST GATE` | S49 mixed 1,024-contract stream/report test rejected one frame at high-water 480/512. The loss latch is appropriate; throughput is not qualified. |
| Test suite | Incomplete | Existing S49 configured evidence: 910 cases, 905 pass, 1 failure, 4 retained gates. Full repository run stopped after 1,196/2,783; not a full-suite pass/fail result. No test was rerun for this audit. |
| Risk and execution | Capital blocked | T3 and T2 independently confirmed the hard sizing formula omits funding required by frozen authority. Native fill-time stop/readback, authenticated venue state and liquidation semantics remain unqualified. UNKNOWN/reservation controls are conservative in reviewed local code. |
| Strategy value | `NOT ESTIMABLE` | S1–S3 are quantity-free research candidates; S4–S5 context; S6 excluded from new-run selection; S7 safety/context; S8 basket research. No after-cost edge, actual fill, prospective outcome floor, or capital permission is demonstrated. |
| Retention/performance | `NOT ESTIMABLE / TEST GATE` | One historical 38-minute group reported 3.60 GB filesystem output and 789,296 KiB peak RSS. These are write churn and a one-time peak, not retained growth or a leak. Selected-device, full product, daily storage/network and endurance results are absent. |
| Cloud environment onboarding | Partially present, not rerun | Current venv already contains editable Atlas from stale `/workspace/Atlas` Session 001 checkout. The onboarding draft points to that stale ref and includes broad tests; it was inspected, not changed or executed under the audit’s no-config/dependency/test and disk-cap rules. |

## Ten material findings and gates

1. **P1, full-breadth data delivery:** bounded S49 workload rejected one frame at queue high-water 480/512. Repair scheduling only under the same queue/loss limits and demonstrate gap/resync durability.
2. **P1 before capital, hard sizing:** per-unit size bound uses stop/stress and taker fees but omits funding. Add a conservative horizon/settlement bound or return `NOT_ESTIMABLE`; reconcile to avoid double counting.
3. **P1 before capital, market-data quality:** shared technical/active-history inputs accept ordered but non-contiguous H4/H1 bars. ATR can set S1 stop geometry and therefore quantity. Require explicit cadence/reset/warmup and fail closed at the risk boundary.
4. **P1 target gap, amendment required:** the target Decision Brief/agent chooser/memory workflow is not wired to production. Current provider and agent settings are deliberately disabled. Do not integrate discretionary influence until a versioned policy amendment is accepted.
5. **P2 V1 chronology:** V1 snapshots can claim computation before all source inputs were available. Tighten availability/finality/computation ordering and test persisted consumers.
6. **P2 V1 identity:** the V1 snapshot hash omits return history and variance; blank/reused source IDs are accepted. Bind canonical payload and source references under a versioned artifact identity.
7. **P2 feature completeness:** generic prior-day range/VWAP descriptors can be built from partial or duplicated data without a coverage state. No hard-sizing consumer was demonstrated; label/fail partial descriptors.
8. **P1 long-running pilot gate:** no general production TTL/quota/refcount retention policy was established; database, WAL, archive and histories have durable consumers. Establish reference-safe cleanup and write/retained-byte accounting before extended operation.
9. **P1 qualification gate:** whole-product/owner-device RAM, CPU, network, disk-growth and low-resource Linux measurements are missing; Windows remains `BLOCKED BY ENVIRONMENT`.
10. **Readiness gate, not edge evidence:** S1–S8 code roles do not prove profitability. Candidate ranking precedes economics, there is no same-slot runner-up substitution, and the owner’s prospective 8-week/200-matured-opportunity floor remains unstarted. Keep all edge claims `NOT ESTIMABLE`.

Other audit-level limits: owner-approved source coverage is 22/24 because two documents were waived; T2 could not confirm a full read after output truncation; T1/T3/E1/E2/E3 reported full reads of available files; all 9,141 tracked Python declarations are indexed but not all deeply reviewed; public research retrieval returned tunnel 403; Luna model IDs and exact parallel start order are not in returned metadata.

## Cross-review and dissent

T1/T2 independently reviewed each S1–S8 signal and entry path; T3 added exposure/sizing review. T2/T3 both confirmed the funding omission, the candidate-set `NOT_ESTIMABLE` behavior, and the limits of portfolio ES claims. T3 found no material disagreement with T1; cadence gaps can affect ATR-based size, while generic partial-day descriptors and candle-volume features do not directly enter hard sizing. No trader disagreement remains in the completed cross-review matrix. The unresolved questions are empirical and qualification gates, not a majority vote about profitability.

## Small next-work sequence

1. Resolve funding-aware hard sizing and gap-qualified indicator inputs before any future capital authorization; add the V1 chronology/hash regressions.
2. Reproduce and fix the mixed-load handoff failure under the same bounded queue and latency SLO; measure durable gap recovery and stop below the 5,000,000,000-byte/24h write ceiling.
3. Establish per-class retention/reference checks and whole-product resource instrumentation on the actual target device before a long-running pilot.
4. Obtain an independently accepted versioned amendment before wiring Decision Brief/agent selection; then exercise only fake providers and preserve zero order/risk authority.
5. Complete independent public-method research and audit-source/model metadata verification when the references and verified metadata are reachable. Do not convert synthetic success into live/edge claims.

The detailed evidence, remedies and acceptance criteria are in reports 01–10 and `audit_manifest.json`. No implementation work is included.
