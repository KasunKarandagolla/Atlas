# E3 — system integration, agent/product, performance and retention review

## Scope and evidence handling

- Repository: `/tmp/atlas_readonly_audit_a73c92d83ca8/repo`, HEAD `a73c92d83ca8b2fe5163e636b2c9732361b35e23` (confirmed exact).
- Source snapshot: `/tmp/atlas_readonly_audit_a73c92d83ca8/sources/Red`: **22/24 Markdown source documents plus `MANIFEST.json`**. I completed a full read of all 22 present Markdown files and the manifest. All 22 present files match the manifest's byte counts and SHA-256 digests; the two absent Markdown files were explicitly waived by the user, and this report does not infer their contents. Hash/read receipt is below. The manifest does not contain a self-hash, so its listed digest is a local receipt only. Authorities cited as source docs are target/freeze/runbook materials, not implementation proof.
- Read-only review. No test was run, no code/config changed, and no provider/market request was made. Resource values below are fields/instrumentation present in code; this pass made no runtime measurements.
- Evidence labels: **CONFIRMED** means directly supported by checked-in implementation or explicit authority text. **HYPOTHESIS** means likely operational effect or an issue requiring execution evidence. Confidence is separate from evidence grade.

## Findings

### E3-1 — Proposed discretionary trading agent and Decision Brief are not integrated in the production path

**Severity: High for target completeness; no present capital-authority defect. CONFIRMED. Evidence grade A (code) / A (target authority). Confidence high.**

The target requires cheap Python shortlist and a concise evidence-linked brief before a preferred DeepSeek agent makes a bounded final discretionary selection, with tools for material new information. That is owner-finalized target intent, expressly not an amendment to the active freezes ([target lock] lines 3, 8–16; [owner decision] lines 9–22).

The repository contains relevant parts, but their consumers do not connect them into the normal product loop:

| Production/module seam | Consumer and actual behavior | Coverage assessment |
|---|---|---|
| Desktop launch: `desktop()` → `create_run()` → `launch_run()` → subprocess `ops` → `run_component()` | [product.py] lines 998–1029 launches a detached public-only ops process, strips credential-like environment variables, and rejects any configured non-`DISABLED` provider at lines 1003–1004. `run_component()` composes collection, health, report and deterministic maintenance ([product.py] lines 1398–1478, 1581–1592). | Connected for public research/safety observer; not for paid trading-agent decisions. |
| Desktop provider selector | UI creates a combo containing only `Intelligence disabled`, labels provider dispatch separate from the read-only observer, and has a two-position effort slider ([product.py] lines 2044–2048, 2056–2078, 2117–2121). The desktop smoke contract asserts there are no provider options ([product.py] lines 2342–2367). | Provider is intentionally inaccessible in normal GUI; effort control is only `CONSERVE`/`STANDARD`, not target's 3 levels or model budget. |
| Existing `ResearchProposalRequestV1` / `ResearchJobController.run()` / `AgentJobRepository` | These implement bounded evidence collection, leasing, retries, budgets and result validation ([controller.py] lines 116–159; [persistence.py] lines 427–459). Repository-wide consumer search found no product/runtime construction of `ResearchJobController`; it is not called by `run_component` or the supervisor. | Agent research proposal path exists as a library, not a wired production workflow. |
| `DecisionBriefV1` / `build_decision_brief()` | Builds causal candidate/economics/facts/peer/ML/image/calendar summary with `authority=ZERO`, `shadow_only=True` ([decision_brief.py] lines 548–588, 687–741). | Contract/compiler code exists; repository-wide consumers are only research agent/memory modules, not production runtime. |
| `ResearchAgent`/`ReadOnlyResearchGatewayV1` and `ResearchMemoryV1` | `research/agent.py` describes a fake-only runner, zero authority, no provider calls; memory imports `FakeResearchProvider` ([research/agent.py] lines 1–4, 15; [research/memory.py] lines 1–19). Search found no production caller. | Design scaffold/fake path, not paid agent integration. |
| Hidden action critic | `ActionAssessmentShadowDispatcher` is bounded (one active + one pending) and no-DB worker ([action_critic_dispatcher.py] lines 89–112); it is post-receipt, tool-free, and zero-authority ([action_critic_shadow.py] lines 1–3, 98–109). It runs only when configured `deepseek-v41-action-critic-v1` ([product.py] lines 1662–1669) or explicit CLI `--action-critic-shadow` ([ops_supervisor.py] lines 1247–1260). | Separate measurement arm; cannot stand in for the proposed chooser/tools and must not be repurposed (target lock lines 16). |
| S7 event extraction | Separate fixed OpenAI `gpt-6-astra` event-extraction profile, not DeepSeek discretionary decision; product starts it only for the S7 profile ([product.py] lines 35–37, 1606–1617). The GUI exposes no such profile, and ordinary `launch_run()` rejects all non-disabled profiles (lines 1003–1004). | Code path exists behind a non-GUI configuration; no ordinary GUI launch path. |

**Target-to-code disconnects confirmed:** no production Decision Brief construction, no production `ResearchAgent`/brief-dispatch consumer, no model decision/tool loop, no AI preselection or position-review consumer, no reusable analysis-memo service found, and no open-position/private account model workflow in the non-capital public observer. The target owner decision says these need separately accepted amendment; it also says not to reinterpret the frozen post-evaluation critic as the new role ([owner decision] lines 17–20; [target lock] lines 14–18). Capital/assisted execution remains disabled in this product path.

**Remedy:** after independently accepting the exact policy amendment, compose a versioned brief/job/task seam into the existing sole ops-writer/event coordinator; keep inference I/O outside that writer with current bounded broker/ledger patterns. Add only a typed scoped read-only tool router and fresh position snapshot after private-state and management authority exist. Preserve the frozen critic as a separate zero-authority arm. Keep provider profiles disabled and spend at zero until owner caps/capability proof are configured (owner decision lines 20, 40–57).

### E3-2 — GUI/runtime lifecycle is split and gives the user no one-window ownership guarantee

**Severity: Medium. CONFIRMED behavior; user impact hypothesis. Evidence grade A (code). Confidence high.**

The GUI is explicitly a public-research observer; the collector is launched detached in its own session/process, and Stop is a run-scoped `stop.request` file ([product.py] lines 1017–1024, 1032–1037, 2117–2121). Closing the window only shuts down the report thread pool in the observed `desktop()` cleanup ([product.py] lines 2358–2371); there is no `aboutToQuit`/close handler requesting the ops child stop in this path. **Confirmed:** UI lifetime is not the same as collector lifetime. **Hypothesis:** users may close the window believing collection stopped; explicit status/restart reconciliation exists, but no close-time ownership cue was found.

`run_component()` starts a health-monitor thread and optional separate provider broker process; on broker exit it records provider TEST GATE and continues public evidence collection, rather than automatically selecting a fallback ([product.py] lines 1598–1605, 1662–1687). This is a useful fail-closed/no-fallback behavior for data collection, but it is not a complete lifecycle UI for paid jobs. Heartbeat ages over 30s display TEST GATE; health telemetry can show status/provider/source/disk ([product.py] lines 1838–1858, 1861–1919), with desktop polling at 2s ([product.py] lines 2336–2339).

**Remedy:** make detached ownership explicit (process state, PID/epoch, stop-on-user-action choice, startup duplicate discovery, UI close warning/continue-in-background status). Show component-specific provider process status/reason and queued/abandoned work. Verify that stop, UI crash/relaunch, OS logout/suspend, and provider broker death converge to one accurate run state before enabling provider dispatch.

### E3-3 — Product effort setting does not yet match target semantics

**Severity: Medium. CONFIRMED. Evidence grade A (code) / A (target). Confidence high.**

The target says one slider with multiple levels affecting optional discovery **and model-analysis budgets**, while mandatory observation, complete calendars, open-position safety, and deadlines stay unchanged ([owner decision] lines 32–35). The implementation slider is range 0–1 and persists only `CONSERVE` or `STANDARD`; explanatory text defers one optional broad-research snapshot, and there is no `BALANCED`/`DEEP` or provider-call budget in the GUI ([product.py] lines 136–139, 206–210, 2056–2078). Product run config also admits only these effort values ([product.py] lines 204–210). This has no paid-agent effect because provider selection is disabled.

**Remedy:** after policy amendment, version the budget profile and implement all owner-approved effort levels over optional compute/provider budgets only; explicitly assert mandatory source cadence/calendar and protection are invariant. Do not label the slider as controlling work it does not currently control.

### E3-4 — Resource telemetry is useful for operation, but is not a complete product footprint measurement

**Severity: High as a release qualification gap; no direct runtime fault established. CONFIRMED instrumentation gaps; capacity outcome unmeasured. Evidence grade A (code) / A (source gate). Confidence high.**

**Present ordinary runtime observability:** `resource_sample()` measures process CPU time, thread count, free disk and (Windows only) current RSS/handle count; non-Windows reports peak RSS only, not a current RSS field ([product.py] lines 1040–1072). `monitored_resources()` records DB/WAL, an estimated run footprint from bounded startup inventory plus archive/receipt byte counters, and storage reserve projections ([product.py] lines 1509–1533). Telemetry is persisted every 60s ([product.py] lines 1544–1559, 1722–1728); watchdog also tracks queue/capture backlog, throughput, service gap/duration, disk/WAL growth, current RSS when provided, and persistence latency ([owner_health_monitor.py] lines 168–200).

**Missing or partial in ordinary product telemetry:** no metered network bytes/day, model image/text bytes, end-to-end GUI+ops+provider aggregate RSS, source/IPC worker total CPU/I/O, energy, or measured p95 from this audit. Ordinary Linux telemetry's `rss_bytes` is null (resource function emits `peak_rss_bytes` instead) and the resource sample is scoped to whichever process calls it, so it does not establish combined product memory. No local values were gathered here.

A separate Binance qualification path contains richer Linux-specific `/proc` sampling for RSS, CPU, I/O, host/cgroup pressure and worker resources, and computes a bounded measurement window ([binance_qualification.py] lines 515–531, 613–633, 730–800). This is qualification instrumentation and does not demonstrate an ordinary long-running, equal-feature low-resource workload. Storage preflight is explicit that its broad estimate excludes streams/capture queues, scheduling, decision/report concurrency, file allocation and endurance; even `allowed` leaves `capacity_qualified=False` ([storage_preflight.py] lines 153–197, 230–264). The owner target calls low-resource Linux feature parity and source/provider/performance budgets TEST GATE ([target lock] lines 18–20; [runbook] lines 90–90; [owner decision] lines 54–56).

**Measured vs unmeasured:** measured by implementation at runtime if run: process CPU seconds; thread count; Windows RSS/current handles; Linux peak RSS; free disk; SQLite/WAL; some capture/archive bytes; bounded queue and event rates; a limited offline disk-cycle probe. **Not measured by this audit:** any actual values. **Unverified/not covered:** total product RSS/CPU, household network use, paid prompt/image bytes/cost under proposed agent flow, 24h/48h growth/endurance, real source burst/backlog recovery, full equal-feature modest-Linux benchmark and GUI responsiveness under load. Existing historical Linux 512 queue burst evidence is not a throughput qualification (runbook lines 29, 90).

**Remedy:** before any shadow/product acceptance, add whole-process/cgroup measurements (desktop, ops, collectors/workers, provider separately and aggregate), per-interface RX/TX deltas by source/venue/provider, bytes/item and bytes/day, disk class growth/WAL/checkpoint/recovery, p50/p95/p99 queue/service/deadline timings, and full calendar coverage; run identical configured features/deadlines on low-resource Linux and reference hardware with source gaps/bursts and provider disabled/enabled test doubles. Keep operational budgets disabled until measured thresholds are accepted.

### E3-5 — Durable records exist, but target retention/compaction policy is only partly implemented

**Severity: Medium now / High for indefinite deployment. CONFIRMED state foundations; absence of general retention service from reviewed production consumers. Evidence grade A (code) / A (target authority). Confidence medium-high.**

| Data class | Current evidence and observed lifecycle | Current classification |
|---|---|---|
| Run configuration/identity, launch/epoch/status, reports | Files under selected run root; launch and epoch records are immutable/published and status is rewritten. Default run root is selected by the owner. Detached collector survives UI. | Persistent on disk; no general run-pruning UI/service observed. |
| Market observations, capture receipts/archive and scientific artifacts | `ops.sqlite` plus WAL and `ops-observations` archive; inventory/size and capture bytes contribute telemetry ([product.py] lines 1424–1434, 1510–1529). Frozen V2 expects causal evidence and decision/outcome lineage retained; raw unreferenced L2 may have shorter retention, but referenced replay evidence may not be silently removed ([V2 freeze] lines 1822–1877; [runbook] lines 86, 90). | Persistent/append-oriented; exact production retention/deletion policy and long-run disk bound not demonstrated here. |
| Watches, expiry, due work, decision/outcome calendar | Existing watch records use expiry/state/version in SQLite; production has explicit expiration transitions and typed due-work maintenance. Expiration is a state transition, not proof of record/file deletion ([memory/repository.py] lines 931–971, 1077–1082; [production.py] lines 1662–1665). | Active obligations durable; expired results/terminal calendar should remain addressable. |
| Agent job/critic/event-extraction ledger | Agent and critic repositories bind to WAL `ops.sqlite`; controller-owned writer and terminal states are persisted ([persistence.py] lines 427–459, 998–1035). Critic migrations install immutable ledger/triggers and agent histories. | Persistent, auditable, append-only intent; no age/size compaction shown in the normal product path. |
| Proposed Decision Brief research memory | `ResearchMemoryV1` stores brief/request/trigger/terminal artifacts through artifact index and typed due-work; source-unavailable/expired jobs are terminalized, not automatically retried ([research/memory.py] lines 69–92, 97–168, 170–199). | Existing fake zero-authority scaffold, not production consumer; terminal semantics do not equal retention cleanup. |
| Temporary/report/provider data | `_publish()` atomically replaces status files and removes its temporary file after publish ([product.py] lines 63–80); periodic report worker is bounded, chart-vision feature/cache is absent. Broker epoch status/context artifacts are separate files. | Some scratch cleanup exists; no general image/analysis-cache cleanup because target cache service is not wired. |

Owner target explicitly requires no infinite ephemeral memory; active risk/watch obligations survive until resolved; causal decisions/economic evidence stay replayable; caches need bounded TTL/LRU/size limits; expired jobs compact only when dependencies permit; admission requires free-disk reserves and measured growth ([ADR-007] §8; [owner decision] lines 46–49). Implementation has disk reserve stop and capacity projection, but projection is not endurance qualification. I found no normal runtime mechanism that enforces a global quota/TTL/refcount cleanup policy across run roots, SQLite histories, old reports, archives, models or future image artifacts; this is a bounded search finding, not proof no lower-level file retention exists anywhere.

**Remedy:** define and version retention by class, implement indexed dependency/reference checks before cache cleanup, preserve terminal calendar/outcome/protected-fault evidence, export/backup policy, and enforce total run/archive/WAL/report/cache quotas. Add recurring cleanup receipts (bytes before/after, references checked, items compacted/deleted and reason) plus disk-full/restart tests. Avoid deleting immutable historical evidence to create a green disk result.

### E3-6 — Runtime failure behavior generally fails closed, with known operator gaps

**Severity: Medium. CONFIRMED. Evidence grade A (code). Confidence high.**

- `launch_run()` rejects configured model provider and enabled exchange credentials; starts public observer after immutable run/preflight checks; low disk reserve causes `TEST GATE` shutdown ([product.py] lines 998–1029, 1693–1696).
- Ops receipts enforce `agent_mode == DISABLED`, `capital_enabled=False`, and `assisted_enabled=False` ([ops_supervisor.py] lines 352–362); hidden critic I/O never blocks the ops writer and completion drain is bounded ([ops_supervisor.py] lines 801–812; [action_critic_dispatcher.py] lines 89–111).
- Provider startup failure is recorded, critic broker loss abandons pending critic work and resumes statistical-only shadow, and S7 broker loss is surfaced while source capture remains active ([product.py] lines 1662–1687). No provider fallback occurs (line 1678 comment; owner authority also bars silent fallback).
- Main operational caveat: exceptions are collapsed to a typed error class in run state; GUI shows summarized provider reason, not a durable operator incident workflow. Detached child ownership and separate provider status make stop/close/restart semantics a review gate, not proven usability.

**Required failure coverage before future enablement:** confirm exact process lifecycle on UI close/host suspend/reboot, stale heartbeat, disk full, WAL growth/checkpoint failure, capture burst/reconnect, broker lost/unknown API completion, budget exhaustion, evidence source unavailable, and restarts with pending/expired jobs; prove calendar status remains visible and no stuck due-work/job duplicates dispatch. No tests were executed in this review.

## Prioritized remedies

1. **P0 before agent shadow:** accept/version exact chooser role and insertion point; wire Decision Brief compiler and one bounded job to the production coordinator; add read-only tool loop, per-call/job/day/month spend and byte budgets; retain separate hidden critic. No provider call until budgets and capability matrix are approved.
2. **P0 before any Linux capacity claim:** gather whole-product resource/network/disk values, bound production queues under burst/recovery, demonstrate equal feature/deadline completion at target device tier; current storage model is a headroom estimate only.
3. **P1 before long-running pilot:** implement versioned retention/compaction with references and durable cleanup evidence; decide global run/archive retention and export/backup.
4. **P1 before GUI-led pilot:** explicit observer/collector ownership and close/restart status; make `CONSERVE`/`STANDARD` semantics match only current behavior, then version approved effort tiers including model-analysis budgets.

## Source snapshot read receipt

SHA-256 values below are for the 22 Markdown files plus `MANIFEST.json` present in the supplied `Red` snapshot; source inventory count is 22 Markdown files, not the 24 the package index says can be uploaded. (Hash command: `sha256sum /tmp/atlas_readonly_audit_a73c92d83ca8/sources/Red/*`.)

| Source | SHA-256 |
|---|---|
| `00_START_HERE.md` | `1901f20a0f7b3f229b114b316ea83f32e78d7bcab681cf126fcd6be9ea44dff7` |
| `04_ATLAS_ENGINEERING_EXECUTION_RUNBOOK.md` | `8be2363d39f91fe796ac6d84bc066dcc0dfc3e70cdb628d6630bac4e321535b6` |
| `ADR-001_Binance_Causal_Market_Data_Linux.md` | `23718723d44c2f4211a21078e848a09934a09d01857fb4922d945024dfa6972b` |
| `ADR-002_Agent_Opportunity_Decision.md` | `2d80ac6dd939f8dfb92ea3da6b547bc92fdd840ab069aabceacbbda100156bb5` |
| `ADR-003_Position_Protection_Lifecycle.md` | `17150dd4f3b3fb85a056aa2600597bcdd317fc4338adeff90bfbb8d4f6d2715f` |
| `ADR-004_Mature_Libraries_Pretrained_ML.md` | `2fb5b4c78e8d6ab843daffccaa728eb253a1918070e41234e58ed9a84683036a` |
| `ADR-005_Independent_Quantitative_Trade_Assessment.md` | `1f7a33f5cebec5310941a4ff0637232586bf6bef15ba4f6ec213ed78d79e22ca` |
| `ADR-006_Agent_Initiated_Trading_Analysis_Tools.md` | `900a81459448fea2883097d4f650cf231e6fe863d92d5cefad13e3f34912b53d` |
| `ADR-007_Durable_Trading_Opportunity_And_Analysis_Memory.md` | `747a8ec425efa445771b46faddc0b118f237626bcc2c2a094dc422ac478a09b4` |
| `ADR-008_Event_Driven_LLM_Vision_Cost_And_Bandwidth.md` | `6206c23e038bd9f8f1273be6e8ea4f7823fbcf65f331fa04a62eb2560cfeb2ae` |
| `ADR-009_Capital_Aware_Discovery_And_Manual_Control.md` | `1adff9b89b91f3f4e625622395ac42a0b5e9194ebe9c0728e8d026b942f4dc83` |
| `ADR-010_Cached_Cross_Coin_Relationships_And_Peer_Context.md` | `b47474f750bc6b03571f799a7fd819e1cb31249ce840306d05d139ae3501bca8` |
| `ADR-011_Chart_Vision_Provider_And_Artifact_Contract.md` | `90c5f143b477372aef34ecd51d363a2268ee3e28b246734b6d09a030972ae7ad` |
| `ATLAS_AGENT_INTELLIGENCE_EXTENSION_FREEZE_V1.md` | `d3e7b0b3da8a2a776db5dd05c656dbc5f04f3d8b1dfaaaec3fbd66966931682d` |
| `ATLAS_DESIGN_SIGNOFF_AND_OPEN_GATES.md` | `65d277ff2640b6d4ac0e5fbb688356d1cd7632c5bbc880624be71547f84b36b8` |
| `ATLAS_FINAL_IMPLEMENTATION_CLARIFICATION_AND_V1_FREEZE_COMPLETED.md` | `c13cad1ba2f3f8c250d55099017770f5144c6cfd71be4bee1e65c5f075806a5c` |
| `ATLAS_FINAL_TARGET_DESIGN_LOCK_2026-10-12.md` | `debe11c6cb0763eaed7e7d628e3dd6260635e6edaaa4a9cab39a4273be5b3265` |
| `ATLAS_OWNER_DECISIONS_AGENT_AUTHORITY_DISCOVERY_ALTCOINS_2026-10-12.md` | `d323030cebc6d8d17d6401765ed49c250548e2fa9ab57e074933cf364bcb8c92` |
| `ATLAS_TRANSITION_ADVERSARIAL_DESIGN_REVIEW.md` | `8c1400e5972a75612e6586ddd338f0a8eceab7ac8ec65ab6eb359916627b08f8` |
| `ATLAS_TRANSITION_ARCHITECTURE_DESIGN_V1.md` | `2a5735ee29c73c079744f96504a0fe7e5cff86c81a8a2de7766b5974d75e1dfe` |
| `ATLAS_TRANSITION_FREEZE_TRACE_AND_APPROVAL.md` | `21fdbfe8b076209cc3eb1bdc7f1f9863c416157662350ff2d6ed81b4291c9448` |
| `ATLAS_V2_FINAL_INTRADAY_INTELLIGENCE_IMPLEMENTATION_FREEZE_AMENDED_2026-09-25.md` | `e868e3e25230fb7fe334e769949bd0d8892edcf66804b0b773cd37ebb2d8fe78` |
| `MANIFEST.json` | `447dbfc8219b943c693b141767e14f494272f73380b9acbc4a99c1a121e668b1` |

**Read and digest verification record (2026-10-13):** all 22 present Markdown files were read fully from start to end, including the two long freeze documents and consolidated runbook. SHA-256 and byte counts were computed from the supplied files and compared with the corresponding `MANIFEST.json` entries; result: **22/22 match**. `MANIFEST.json` was read in full and its local SHA-256 above recorded; it does not list a digest for itself. The only manifest-listed source documents absent from the snapshot are `01_CHATGPT_PROJECT_INSTRUCTIONS_COPY_PASTE.md` (expected SHA-256 `d6922d82de2383bff1e8e7d87490c69baa421b9e28c2b430945b7758b924860f`) and `02_NEW_PROJECT_FIRST_CHAT_KICKOFF.md` (expected SHA-256 `49c68c9284e22a99ba9d093dc361cf937884c6b9d29e0bcfa9160a7b29531d1f`); their absence was waived by the user.

## Citation key

Repository citations are root-relative paths and line numbers at the pinned SHA. Source-document citations above use the `sources/Red` file name plus its line number or named section. The accepted freezes and target lock remain authority; runbook/ADR drafts are target guidance; code and present runtime measurements determine implementation status.

[product.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/product.py
[controller.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/agent_intelligence/controller.py
[persistence.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/agent_intelligence/persistence.py
[decision_brief.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/research/decision_brief.py
[research.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/research/agent.py
[memory.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/research/memory.py
[action_critic_dispatcher.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/action_critic_dispatcher.py
[action_critic_shadow.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/action_critic_shadow.py
[ops_supervisor.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/ops_supervisor.py
[owner_health_monitor.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/owner_health_monitor.py
[storage_preflight.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/storage_preflight.py
[binance_qualification.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/binance_qualification.py
[production.py]: /tmp/atlas_readonly_audit_a73c92d83ca8/repo/src/atlas/v2/runtime/production.py
