# E2 — Quantitative risk, execution and persistence review

**Review target:** `/tmp/atlas_readonly_audit_a73c92d83ca8/repo` at `a73c92d83ca8b2fe5163e636b2c9732361b35e23` (HEAD verified; working tree clean at start). **Scope:** static review of risk sizing/portfolio constraints, order submission and UNKNOWN handling, idempotency, bounded queues/backpressure, SQLite/WAL and evidence archive/restart, resource admission, tests and handoff evidence. No tests or external calls were run; no code/config was changed.

## Decision

**Do not enable capital or claim execution/capacity qualification.** The inspected controls are deliberately conservative: they persist intent/reservation before external effects, preserve UNKNOWN as possible exposure, gate new entry, require identity-bound reconciliation and stop readback, and fail on bounded-queue loss. However, hard release blockers remain: actual Binance entry and fill-time native protection semantics are unqualified; broad mixed-load stream/report/persistence capacity has recorded failures; and target-device full-workload disk/RSS/WAL/drain figures are not established. These are qualification gaps rather than evidence that safety controls should be relaxed.

**Evidence grade:** B for static implementation paths and test inventory; C for handoff artifacts tied to earlier/different SHAs; no fresh execution evidence on the pinned SHA. Confidence: high for stated state-machine behavior, medium for behavior across all call paths, low for actual venue/capacity performance. Capital/assisted flags are recorded false in S41 handoff artifacts; this review did not exercise them.

## Findings

### E2-1 — Opening execution is fail-closed pending real Binance qualification

`dispatch_persisted_demo_command` asserts writer ownership, requires an UNSENT/no-send-started command, and categorically blocks `SUBMIT_ENTRY` before marking send-started at [`binance_demo.py:602-620`](../repo/src/atlas/runtime/binance_demo.py). Other admitted commands persist send-started/UNKNOWN before the port effect; an exception leaves UNKNOWN and retains the reservation, and the API explicitly says an asynchronous OMS enqueue is not venue acknowledgement [`binance_demo.py:622-634`](../repo/src/atlas/runtime/binance_demo.py). Native queues are bounded (32 commands, 256 events; max 8 commands per tick) [`binance_native.py:38-45`](../repo/src/atlas/runtime/binance_native.py).

Recovery hydrates only eligible unsent non-opening commands; tests encode restart-before-enqueue, no re-enqueue after UNKNOWN/terminal state, and fresh readiness proof requirements [`test_session041_binance_unsent_recovery.py:78-113,159-195`](../repo/tests/runtime/test_session041_binance_unsent_recovery.py). The independent S41 execution review likewise says opening remains unqualified, and that a stop readback/repair is not proof of attached fill-time protection (`SESSION041_EXECUTION_FINAL_REVIEW.json`, `freeze_invariants` and `Binance` clauses; historical artifact, not a fresh test).

**Failure sequence / counterexample:** intent and reservation commit; send-started commits; process dies before the native strategy actually reaches the venue. The command is now UNKNOWN and cannot be automatically resent, even if no order exists. This is an intentional conservative ambiguity, but the owner must reconcile it; if readback is incomplete the reservation remains and new risk stays blocked.

**Severity:** Release blocker for capital; control design itself passes static review. **Remedy:** keep opening gate closed until the pinned Nautilus/venue adapter and actual selected demo account demonstrate immediate/partial fills, conditional stop coverage at fill, lost ACK, process kill/disconnect, cancel/replace and stop/exit race with complete readback and restart proof. Evidence grade B (code + focused test inventory), C for older review, confidence high on fail-closed path / low on exchange equivalence.

### E2-2 — UNKNOWN, client identity and reservations are handled conservatively

Client-order identity is unique in the journal schema (`client_order_id TEXT NOT NULL UNIQUE`, `schema.py:46-68`). `mark_send_started` enforces a legal transition to UNKNOWN and is single-use (`sqlite.py:1111-1127`; transitions in `domain/transitions.py:90-91`). V1 assisted-control revalidation rejects unresolved intents/commands and includes journal reservation totals in current risk (`assisted_control.py:187-193,237-251`). The dispatcher refuses redispatch after a send start (`binance_demo.py:602-606`). Binance reconciliation associates observed regular/algo client IDs with a durable command, validates symbol/account/product identity, preserves incomplete/malformed statuses as unknown, and documents that cancellation alone never proves no fill (`binance_reconciliation.py:136-157,176-218`).

Risk release requires persisted certified-flat evidence bound to the intent and a complete verified artifact; releasing zeros the reservation only inside the checked transaction (`sqlite.py:888-936`). Recovery tests explicitly reject a caller-supplied “flat” label with only a positions query and retain a recovery incident for incomplete evidence (`test_recovery_persistence.py:45-78,81-107`).

**Failure sequence / counterexample:** venue accepts an order but the ACK/event stream is lost, then a partial fill occurs before restart. The same command remains UNKNOWN; its whole possible exposure stays reserved, and a mere empty open-orders response cannot prove no fill. Safe availability degrades, but duplicate opening risk is avoided.

**Severity:** No confirmed defect in reviewed seam; qualification blocker remains. **Remedy:** preserve natural-id dedupe and require complete account/order/conditional/fill history before reconciliation or flat certification. Evidence grade B; confidence high for local logic, medium for all venue-status mappings because no venue call was made.

### E2-3 — Quant risk controls are explicit, but depend on qualified inputs and production scope

The V1 deterministic reservation check enforces per-trade and aggregate normal loss, stress loss, portfolio ES, gross/instrument notional, absolute correlated beta, free-margin reserve, leverage, venue collateral and simultaneous-intent limits [`risk/engine.py:48-78`]. The common-path portfolio decision computes ES before/after with paired losses, and its contract explicitly includes pending/UNKNOWN exposure in `Pi0` [`risk/portfolio.py:12-27,40-53`]. V2 risk artifacts are content-addressed and cutoff-bound; source refs must be indexed and available by the decision cutoff [`v2/risk.py:44-65,117-169`]. Production qualification evidence notes only selected candidates flow through sizing/action/evaluation; other strategy surfaces remain standalone or diagnostic, not capital-enabled (`docs/v2/SESSION041_WORKSTREAM_E_AUDIT.json:9-23,26-40,57-69`).

**Counterexample:** an input account snapshot omits a pending reservation or reports stale available margin. Mathematical risk limits can still calculate correctly against incomplete state; the operational gate must reject stale/incomplete account/reconciliation evidence. Existing V1 revalidation checks age and unresolved state; actual account completeness/wire correctness remains external proof.

**Severity:** Medium, evidence/input qualification and production-scope limitation. **Remedy:** retain complete source-bound account/exposure evidence and show exact production policy/action reachability before any future capital contract. Do not interpret a module/test path as strategy qualification. Evidence grade B; confidence medium-high.

### E2-4 — Bounded queueing fails visibly, but mixed-load capacity is a known blocker

Broad stream lanes share fixed 512-item / 16,000,000-byte capacity with per-lane reserve and a 64-frame drain bound; status exposes high-water, rejections, loss latch and pressure rather than silently dropping (`v2/data/broad_stream_source.py:175-214,239-272,288-344`). Current capture is designed around one durable FIFO for both lanes (`broad_stream_source.py:347-365`). On overload, the safe outcome is terminal stop, not an unbounded queue.

Historical S41 measurements show the real limitation: with a synthetic 1,024-contract workload, 16-frame capture hit preventive pressure after 1,419 frames (209 delivered, 1,210 pending; 62/64 descriptors); another run rejected at 480/512 due to protecting the idle Binance lane; increasing batch size to 32 retained 1,791 frames but had 2.399 s max stream-service gap and 2.310 s service call, over the 1.5 s bound (`SESSION041_FULL_V2_ENGINEERING_CLOSURE.md:17-21`; also `SESSION041_HANDOFF.md:83-87`). A narrower dual-venue paging integration handled 100 ms/500 ms/1 s injected lookup stalls with a 1.023 s max gap against a 1.201 s bound; that is not broad-capacity proof (`SESSION041_FULL_V2_RESILIENCE_VALIDATION.json:7-9`).

**Failure sequence:** report export + a burst + persistence stall grows accepted capture descriptors faster than the 16-frame service cadence can drain. The recorder stops before silent loss; the current 32-frame experiment services faster but violates the latency SLO. Either way the required mixed profile is not qualified.

**Severity:** High / release blocker for full-breadth service. **Remedy:** resolve the capture/export/persistence scheduling hotspot using a measured equivalent-input workload; retain limits, SLO, source cadence and loss latch until a passing result. Evidence grade C (historical synthetic reports; exact pinned SHA not exercised); confidence high that the recorded test failed, low on extrapolation to owner-device throughput.

### E2-5 — WAL and archive integrity mechanisms exist; lifetime capacity is unproven

The V1 journal sets WAL, `synchronous=FULL`, and foreign keys, verifying all three on open (`persistence/sqlite.py:66-94`). V2 `OpsRepository` also verifies WAL/FULL (`memory/repository.py:617-629`) and provides passive checkpoint telemetry (`memory/repository.py:720-740`). Public durable capture verifies the previous sealed receipt and indexed extent before a new run, and fails startup on unclean/corrupt lifecycle (`v2/data/durable_public_capture.py:182-215`; archived bytes are re-read at 202-209). Raw observations bind event identity and payload hash, distinguish receipt/ingest/availability, and reject impossible chronology (`v2/data/raw.py:40-55,57-115`). This gives strong local provenance and restart fences.

Capacity remains a blocker rather than a guessed estimate. The S41 docs report a separate short F1 failure in 7.75 seconds: 112 indexed / 1,206 captured / 1,094 pending, 200.14 ms mean 16-frame processing, 1.601 s max service gap, with no measured burst (`SESSION041_FINAL_LIVE_TEST_READINESS.md:5-11`). Historical 4,096-contract bulk tests explicitly omit streams, reports and WAL contention; mixed-workload storage, WAL growth, archive/day, owner host and full-drain metrics remain open (`SESSION041_HANDOFF.md:53-55,66-71`).

**Resource status:**

| Metric | Status from inspected evidence |
|---|---|
| Handoff cap / batch cap | Measured configuration: 512 items, 16,000,000 bytes; drain max 64. Not a capacity pass. |
| Synthetic 1,024-contract burst / service gap | Measured failures above. |
| Small injected paging-stall service | 1.023 s max vs 1.201 s bound; limited scope. |
| CPU/RSS on selected owner device | **NOT ESTIMABLE** from pinned review. Prior test host descriptions vary by run; they are not owner-device measurements. |
| Disk bytes/day, archive growth, WAL high-water/checkpoint drain under mixed production load | **NOT ESTIMABLE** / mixed-workload capacity gate open. |
| Full broad-source input rate, queue headroom, complete backlog drain, real Binance close+5s receipt performance | **NOT ESTIMABLE** for intended workload; source/host qualification absent. |
| Actual market economics/profitability | **NOT ESTIMABLE**; no prospective economic evidence is established by engineering runs. |

**Severity:** High / release blocker for sustained broad workload and resource promises. **Remedy:** qualify the exact device/profile with declared full source rates plus reports, injected persistence stalls, old DB geometry and restart; measure CPU/RSS, WAL/archive growth, service gap and full drain. Preserve failure reports. Evidence grade C; confidence high on what is and is not measured.

## Test coverage and handoff evidence

I inspected test files but did not execute tests, as instructed. Focused static inventory includes V1 lifecycle/recovery, fault injection, flat certification, protection deadlines/readback, Binance demo/native/readiness/reconciliation/unsent restart tests; persistence journal, migrations, execution evidence and recovery tests; V2 broad capture, queue reserve/backpressure, restart, recovery adoption, block cache/migration, storage preflight, resource telemetry and portfolio ES/sizing tests. Examples: `tests/runtime/test_session041_binance_unsent_recovery.py`, `tests/runtime/test_session041_binance_native.py`, `tests/runtime/test_session041_binance_reconciliation.py`, `tests/runtime/test_protection_deadline.py`, `tests/persistence/test_recovery_persistence.py`, `tests/v2/test_session041_capture_pressure_reserve.py`, `tests/v2/test_session041_mixed_broad_capacity.py`, `tests/v2/test_session041_storage_preflight.py`, `tests/science/test_portfolio_es_risk_sizing.py`.

The repo contains historical JUnit/report references and broad suites, but S41 reports are historical and bind earlier SHAs, not this audit SHA. The source handoff itself cautions that selected queue tests passed while full suite, 30-minute capacity, native Windows, security/dependency and final review gates did not (`SESSION041_HANDOFF.md:9-18`). Therefore no test on this exact pinned commit is claimed here.

## Decision matrix

| Area | Finding | Release decision |
|---|---|---|
| Order ownership / UNKNOWN | Persist-before-effect, immutable ID, no blind resend, unresolved exposure retained | Accept conservative design; keep capital off until actual venue proof |
| Native stop / entry | Entry hard-gated; fill-time protection and race wire unproven | **Block** |
| Quant risk / portfolio | Deterministic hard limits and paired ES; depends on complete fresh inputs | Retain; independently qualify evidence and exact production policy |
| Queue/backpressure | Explicit finite bounds and loss latch; known mixed-load failures | **Block full breadth** |
| SQLite/WAL/archive/restart | Strong FULL/WAL/hash/receipt/recovery controls visible | Accept implementation pattern; capacity/restart on target profile remains unqualified |
| CPU/RSS/disk/network/endurance | Selected-device and mixed-load measurements absent | **NOT ESTIMABLE / TEST GATE** |
| Economic value | No qualifying prospective sample established | **NOT ESTIMABLE** |
| Tests on pinned SHA | Not run by this reviewer; handoffs predate/differ from SHA | No pass inferred |

## Source packet coverage and SHA receipts

Source coverage: I read **all 22 present Markdown files in full**, using sequential bounded chunks for the longer files, and read `MANIFEST.json` in full. The manifest lists 24 Markdown entries; two were absent and waived by the user: `01_CHATGPT_PROJECT_INSTRUCTIONS_COPY_PASTE.md` and `02_NEW_PROJECT_FIRST_CHAT_KICKOFF.md`. SHA-256 verification against the manifest passed for all 22 present Markdown files (0 mismatches); the manifest SHA-256 is also recorded below (the manifest does not self-hash). The runbook consolidates eight original source materials; their names and original hashes are in the manifest, not separate present files. SHA-256 receipts:

```text
1901f20a0f7b3f229b114b316ea83f32e78d7bcab681cf126fcd6be9ea44dff7  00_START_HERE.md
8be2363d39f91fe796ac6d84bc066dcc0dfc3e70cdb628d6630bac4e321535b6  04_ATLAS_ENGINEERING_EXECUTION_RUNBOOK.md
23718723d44c2f4211a21078e848a09934a09d01857fb4922d945024dfa6972b  ADR-001_Binance_Causal_Market_Data_Linux.md
2d80ac6dd939f8dfb92ea3da6b547bc92fdd840ab069aabceacbbda100156bb5  ADR-002_Agent_Opportunity_Decision.md
17150dd4f3b3fb85a056aa2600597bcdd317fc4338adeff90bfbb8d4f6d2715f  ADR-003_Position_Protection_Lifecycle.md
2fb5b4c78e8d6ab843daffccaa728eb253a1918070e41234e58ed9a84683036a  ADR-004_Mature_Libraries_Pretrained_ML.md
1f7a33f5cebec5310941a4ff0637232586bf6bef15ba4f6ec213ed78d79e22ca  ADR-005_Independent_Quantitative_Trade_Assessment.md
900a81459448fea2883097d4f650cf231e6fe863d92d5cefad13e3f34912b53d  ADR-006_Agent_Initiated_Trading_Analysis_Tools.md
747a8ec425efa445771b46faddc0b118f237626bcc2c2a094dc422ac478a09b4  ADR-007_Durable_Trading_Opportunity_And_Analysis_Memory.md
6206c23e038bd9f8f1273be6e8ea4f7823fbcf65f331fa04a62eb2560cfeb2ae  ADR-008_Event_Driven_LLM_Vision_Cost_And_Bandwidth.md
1adff9b89b91f3f4e625622395ac42a0b5e9194ebe9c0728e8d026b942f4dc83  ADR-009_Capital_Aware_Discovery_And_Manual_Control.md
b47474f750bc6b03571f799a7fd819e1cb31249ce840306d05d139ae3501bca8  ADR-010_Cached_Cross_Coin_Relationships_And_Peer_Context.md
90c5f143b477372aef34ecd51d363a2268ee3e28b246734b6d09a030972ae7ad  ADR-011_Chart_Vision_Provider_And_Artifact_Contract.md
d3e7b0b3da8a2a776db5dd05c656dbc5f04f3d8b1dfaaaec3fbd66966931682d  ATLAS_AGENT_INTELLIGENCE_EXTENSION_FREEZE_V1.md
65d277ff2640b6d4ac0e5fbb688356d1cd7632c5bbc880624be71547f84b36b8  ATLAS_DESIGN_SIGNOFF_AND_OPEN_GATES.md
c13cad1ba2f3f8c250d55099017770f5144c6cfd71be4bee1e65c5f075806a5c  ATLAS_FINAL_IMPLEMENTATION_CLARIFICATION_AND_V1_FREEZE_COMPLETED.md
debe11c6cb0763eaed7e7d628e3dd6260635e6edaaa4a9cab39a4273be5b3265  ATLAS_FINAL_TARGET_DESIGN_LOCK_2026-10-12.md
d323030cebc6d8d17d6401765ed49c250548e2fa9ab57e074933cf364bcb8c92  ATLAS_OWNER_DECISIONS_AGENT_AUTHORITY_DISCOVERY_ALTCOINS_2026-10-12.md
8c1400e5972a75612e6586ddd338f0a8eceab7ac8ec65ab6eb359916627b08f8  ATLAS_TRANSITION_ADVERSARIAL_DESIGN_REVIEW.md
2a5735ee29c73c079744f96504a0fe7e5cff86c81a8a2de7766b5974d75e1dfe  ATLAS_TRANSITION_ARCHITECTURE_DESIGN_V1.md
21fdbfe8b076209cc3eb1bdc7f1f9863c416157662350ff2d6ed81b4291c9448  ATLAS_TRANSITION_FREEZE_TRACE_AND_APPROVAL.md
e868e3e25230fb7fe334e769949bd0d8892edcf66804b0b773cd37ebb2d8fe78  ATLAS_V2_FINAL_INTRADAY_INTELLIGENCE_IMPLEMENTATION_FREEZE_AMENDED_2026-09-25.md
447dbfc8219b943c693b141767e14f494272f73380b9acbc4a99c1a121e668b1  MANIFEST.json
```
