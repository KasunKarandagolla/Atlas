# Target, source, and code-symbol coverage

**Status: INCOMPLETE.** The accepted source snapshot was intentionally waived as to two documents by the owner. Every tracked Python file and AST declaration is indexed below, but the team did not perform deep usage/contract review of every one of the 7,949 functions and methods. The inventory does not convert indexing into review.

## Pinned inputs

- Repository: `KasunKarandagolla/Atlas`, branch reported as `impl/session-049-final-integration-release`.
- Audit pin: `a73c92d83ca8b2fe5163e636b2c9732361b35e23`; detached audit clone was clean at inspection.
- Parent: `00ed85f9dae78b29989e442dfb0d70576671ff48`; S48 parent: `52d9c149cfa1a1bc3f9a955ad94629300d00a7a7`.
- The S49 handoff calls `00ed85fb61c0941f045472319aa19b795577168e` the implementation SHA. That SHA is absent from the Git graph; it must not be presented as the pinned commit.
- Uploaded archive SHA-256: `8be29d4486a061e7d70a6e3d36fdd49caacef371faa617d12887db12e17f008b`.
- Snapshot path: `/tmp/atlas_readonly_audit_a73c92d83ca8/sources/Red`.

The archive’s safe-structure checks passed: expected top-level/wrapper form, no absolute/traversal paths, symlinks, encrypted entries, duplicate member paths, credential/`.env` items, unrelated files, or unexpected oversized files. The 22 present source documents match their declared byte lengths and SHA-256 values. `MANIFEST.json` is also present and matches its own archive receipt; its digest is `447dbfc8219b943c693b141767e14f494272f73380b9acbc4a99c1a121e668b1`. Three frozen-authority digests match:

- V1: `c13cad1ba2f3f8c250d55099017770f5144c6cfd71be4bee1e65c5f075806a5c`
- V2: `e868e3e25230fb7fe334e769949bd0d8892edcf66804b0b773cd37ebb2d8fe78`
- Agent V1: `d3e7b0b3da8a2a776db5dd05c656dbc5f04f3d8b1dfaaaec3fbd66966931682d`

The manifest declares `source_count: 25` and 24 document entries. The uploaded package has 22 of those Markdown documents plus `MANIFEST.json` (23 files total). The owner explicitly waived `01_CHATGPT_PROJECT_INSTRUCTIONS_COPY_PASTE.md` and `02_NEW_PROJECT_FIRST_CHAT_KICKOFF.md`; their declared manifest hashes do not supply the absent bytes. All reviewers therefore have only 22/24 document coverage. T1, T3, E1, E2, and E3 reported full end-to-end reads of all 22 present Markdown files and MANIFEST.json; T1/E1/E2/E3 recorded zero hash/byte mismatches. T2 disclosed it could not confirm a full read because even a single 150-line runbook chunk was truncated, despite verified hash/byte receipts. Its source-read gate remains open. External public-method retrieval is still blocked (see reports 01 and 07).

## Deterministic Python inventory

The generated [source symbol inventory CSV](08_source_symbol_inventory.csv) uses the pinned Git tree’s tracked `*.py` paths and Python AST definitions. It contains 604 Python files: 281 under `src/`, 288 under `tests/`, and 35 tracked scripts/evidence modules. It indexes 1,192 classes and 7,949 functions/methods/async functions (9,141 declarations); all 604 files parsed successfully. The CSV gives every module, class, function, and method a line, a primary engineering owner, and an explicit coverage state. No tracked Python file is left unassigned.

| Primary engineering owner | Files | Indexed declarations | Boundary |
|---|---:|---:|---|
| E1 | 108 | 1,555 | Data, features, strategies, scanner, and market-data tests |
| E2 | 85 | 937 | Risk, persistence, science, model contracts, and associated tests |
| E3 | 411 | 6,649 | Product/runtime/UI/agent glue, remaining tests, scripts, and evidence tools |

Ownership is a review-accountability assignment, not evidence every function was inspected. The CSV marks definitions `INDEXED_ONLY; deep review not claimed`; targeted code review and citations are in reports 01–06. The assigned owners did not establish every cross-module consumer and contract for every indexed declaration. In particular, the complete product call graph, all 9,141 declarations’ callers, all public entrypoints, and all utility invariants were not individually reconciled. This is an explicit coverage failure, not a claim of complete source review.

## Domain report coverage

| Domain | Target/source coverage reviewed | Remaining boundary |
|---|---|---|
| T1 market/indicators | Market-data and feature formulas, chronology, relevant S1–S8 signal meanings, order-flow and VWAP distinctions; citations and matrix in report 01; T1 reported full reads of all 22 present source documents plus MANIFEST.json | No full-market prospective edge or exchange qualification; owner-waived documents remain absent |
| T2 strategy | S1–S8 current roles, candidate path, exact action, cost/outcome boundaries, traps and selection; report 02 | Shadow candidates only; no order/fill/economic proof |
| T3 decisions/risk | Selection, sizing, uncertainty, portfolio ES, protection, lifecycle; independent second opinions in report 03 | Funding-aware sizing discrepancy requires resolution before capital; no live venue proof |
| E1 data/features/strategy code | Key data/feature/strategy paths, chronology findings, module/test consumer matrix; report 04 | Index breadth exceeds deep function review; no stress reproduction |
| E2 risk/execution/persistence | Risk, economics, UNKNOWN, venue/protection, restart and queue findings; report 05 | Capacity, live protection, selected-device storage/RAM remain gates |
| E3 integration/agent/performance | Production callers, desktop/provider, agent, lifecycle, resource/retention seams; report 06 | No complete all-symbol call graph, long-run, Windows, or owner-device measurement |

## Audit evidence versus tests

No test was run in this audit. Existing S49 evidence was read from the pinned handoff, reports, JUnit/XML, and machine evidence. Its configured group contains 910 cases: 905 passed, one reproducible mixed-capacity rejection, and four retained integration/readiness gates. The broader repository run stopped at 1,196/2,783 with six partial failures and five skips; it is not a complete-suite verdict. See reports 05, 06, and 09 for the detailed limitations and write/RSS evidence.

The only code-side diagnostic generated for this report was a static read-only AST inventory. It did not import Atlas, execute test code, or write to the checkout. No repository, branch, environment configuration, dependencies, tests, or credentials were changed.
