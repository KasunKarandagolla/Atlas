# T1 — Market structure, microstructure, and indicator science audit

## Scope and verdict

Read-only audit of repository SHA a73c92d83ca8b2fe5163e636b2c9732361b35e23 and snapshot /tmp/atlas_readonly_audit_a73c92d83ca8/sources/Red. Repository status was clean. No tests were run and no repository code/configuration changed.

**Verdict:** cutoff and revision handling are generally strong, with sound separation between finalized OHLCV indicators, actual trade prints/aggressor flow, and sequenced displayed-book statistics. The main finding is that shared OHLCV/recursive indicator paths accept strictly ordered but non-contiguous bars and still publish ordinary indicators. A second issue is that partial prior-day bars/trades can be surfaced as complete range/VWAP descriptors without coverage/dedup proof. Current strategies are shadow/research only; no inspected formula proves positive after-cost expectancy.

## Findings

### F1 — Rolling OHLCV indicators accept gaps

**Severity:** Medium for shadow research; high before capital eligibility. **Confidence:** High.

Evidence: src/atlas/v2/features/joins.py:25-45 selects cutoff-visible final bars and checks source health, but not interval spacing. src/atlas/v2/features/technical.py:17-23 validates finality, strict order, interval, and revision, but no regular cadence; :26-65, 85-151 then computes EMA/ATR/RSI/ADX/variance over successive observations. src/atlas/v2/data/active_history.py:150-169 similarly requires chronological tail, not contiguous bars; :267-273, 302-346 explicitly retains gaps and still advances recursive EMA/ATR once per observed bar. S1 exact-prefix validation checks identity/availability, not cadence (src/atlas/v2/strategies/s1_trend.py:182-214, 217-243).

**Counterexample:** 50 final H4 bars pass when one 24h gap occurs between them. EMA50 treats the next observation as one H4 step; rolling realized variance can omit missing movements. S1 has enough bars and an exact history suffix, so its regime can still be available. This is causal in availability, but not a complete regular-bar history.

**Remedy:** require typed interval coverage for rolling indicators and strategy inputs, or reset/segment indicator state at gaps and return NOT_ESTIMABLE until declared contiguous warmup is met. Keep gap evidence visible. Do not assume event-count EMA semantics equal time-decay semantics.

Scope qualifier: S2 checks recent M15 spacing (src/atlas/v2/strategies/s2_breakout.py:167-174), S3 checks contiguous M1 AR bars (s3_mean_reversion.py:811-827), S6 creates hourly returns only from adjacent timestamps and requires contiguous H4 context (s6_cross_section.py:767-824), and S8 rejects missing hourly bars (s8_pairs.py:251-255). Those checks do not repair shared ATR/technical features consumed by S2/S3/S6. S1 is the clearest affected decision sleeve.

### F2 — Partial prior-day range and generic trade VWAP can appear complete

**Severity:** Medium. **Confidence:** High.

prior_utc_day_range returns max/min of any selected prior UTC-day bars, with no interval check, minimum count, or coverage state (src/atlas/v2/features/candles.py:84-89). feature_snapshot publishes non-null values without qualification (src/atlas/v2/features/pipeline.py:90-92). A single surviving M15 bar can produce prior-day high/low despite up to 95 missing bars. Require complete declared cadence or label coverage/partial range explicitly.

Generic utc_day_vwap filters by trade event/availability time and positive quantity, then computes VWAP from any remaining trades; it does not require stream coverage or deduplicate trade IDs/refs (candles.py:71-81). feature_snapshot reports normal availability for any non-null value (pipeline.py:93-94). Duplicate prints can distort the result and a one-minute subset can be labeled UTC-day VWAP. This differs from S3's separate completeness-gated path. S1 rejects non-null optional VWAP (src/atlas/v2/strategies/s1_trend.py:267-269, 350-353), and S3 requires completeness (src/atlas/v2/strategies/s3_mean_reversion.py:637-716).

**Remedy:** bind these descriptors to coverage receipts; deduplicate by stable trade identity or reject conflicts; expose covered interval and completeness status. Keep partial-to-cutoff VWAP separate from complete UTC-day VWAP.

### F3 — Flow/book measures are distinct, but displayed quantities are not normalized signals

**Verdict:** Pass on source-type separation and sequence fail-closed design; descriptive interpretation only. **Confidence:** High.

S4 declares sequence-valid book requirements and gap → NOT_ESTIMABLE until fresh snapshot, valid bridge, and warmup (src/atlas/v2/data/microstructure.py:33-49; state machine :365-731). Features bind actual-receipt BBO/depth and require capability-qualified trade coverage and venue side convention for signed flow (:731-923). AggressiveTradeV2 retains BUY/SELL/unavailable semantics (:296-342); production maps Bybit taker side and Binance buyer-maker convention (src/atlas/v2/runtime/production.py:1344-1366).

BBO OFI is a displayed-best-quote price/size-change statistic (microstructure.py:955-978); additions/removals/replenishment/persistence are displayed-book proxies (:980-1035), not executions, hidden liquidity, queue priority, or proof of absorption. S4 absorption is labeled a hypothesis, fit from prior observations, and marked with unqualified engineering thresholds and no exact action contract (:51-60, 1302-1364).

Unit caveat: signed trade window is normalized (buy_qty - sell_qty)/(buy_qty + sell_qty), but flow_price_response_windows stores raw signed base quantity (microstructure.py:814-851). Raw values are not comparable across coins; use only with per-instrument prior baseline. OFI is also a base-quantity displayed-book delta.

### F4 — Candle volume and structure are useful proxies, not order flow

S2 compares finalized trigger kline volume to a 20-bar median (src/atlas/v2/strategies/s2_breakout.py:212-226). This is aggregate candle volume, not buyer/seller aggressor flow or L2 demand. Candle geometry and volume z are bar-derived (src/atlas/v2/features/candles.py:23-44; features/pipeline.py:81-94). S3 explicitly uses public trades, not candle volume (src/atlas/v2/strategies/s3_mean_reversion.py:49-94, 265-306), but requires proven trade completeness (:637-716); production documents completeness as unproven (src/atlas/v2/runtime/production.py:5755-5780). No current S3 opportunity should qualify.

Structure features carry pivot confirmation refs/times and current-close event logic uses only earlier-confirmed pivots (src/atlas/v2/features/structure.py:35-117). “Order block candidate,” sweep, FVG, and morphology remain bar heuristics; they do not prove resting orders or institutional intent. Structure validators also lack cadence checks (F1).

## Strategy and feature matrix

| Sleeve | Inputs and granularity | Warmup / causal gates | Consumer / status | Interpretation |
|---|---|---|---|---|
| Legacy V1 CRYPTO_TREND_24H_V1 | Hourly log closes; 24h log return / sqrt(24) hourly EWMA sigma; 4h decisions (src/atlas/strategy/features.py:10-16, 47-98; crypto_trend_24h_v1.py:25-35) | Exactly 721 contiguous hourly closes; duplicates, gaps and future availability rejected; 48-return seed, 48h half-life (features.py:47-89) | Offline deterministic signal and fixed 24h research plan (src/atlas/strategy/policy.py:55-95) | Standardized trend statistic, not probability or edge. |
| S1 trend/pullback | H4 EMA20/50, three closed H1 EMA pullback/reclaim bars, later M15 close break, ATR, fresh BBO/mark/event (src/atlas/v2/strategies/s1_trend.py:112-160, 199-243) | At least 50 H4/H1 bars; exact suffix; 5s quote/bar limits and universe/event gate (:182-214, 259-289); no explicit cadence | Durable watch then shadow CandidateAction (:250-330) | OHLCV hypothesis; no flow. F1 applies. |
| S2 compression breakout | M15 Bollinger width/ATR compression vs historical 20th percentile and ATR median; prior 20-bar range; trigger close and candle volume (src/atlas/v2/strategies/s2_breakout.py:49-94, 189-226) | 2,880 comparison measurements, t−1 excludes trigger, >=2,901 history bars, recent contiguous M15 and BBO checks (:167-190) | Confirmed breakout creates shadow CandidateAction; fixed stop/time exit (:212-309) | Candle volume is not flow; no L2 inference. |
| S3 VWAP mean reversion | UTC-day public-trade VWAP, M1 log residual, M15 ADX/ATR/variance, H4 trend, BBO midpoint, AR(1)/z (src/atlas/v2/strategies/s3_mean_reversion.py:49-119, 391-445, 637-842) | Contiguous 7d minute residuals; 120 prior values for z; strict abs(z)>2; phi in (0,1), half-life 5–30m; source/universe/event/trade completeness (:637-827) | Watch then subsequent M1 move toward frozen VWAP can make shadow candidate (:870-1000); current production coverage false (src/atlas/v2/runtime/production.py:5771-5780) | True trade-at-price VWAP; mean reversion remains a hypothesis. |
| S4 microstructure | Sequenced L2 BBO/microprice/depth/imbalance; BBO OFI/price response at 1/5/30s; actual trade aggressor flow (src/atlas/v2/data/microstructure.py:731-923, 955-978) | Sequence bridge/continuity, stale gate, warmup, cadence and qualified trade coverage | Diagnostic/execution-quality and S5 input; absorption non-actionable (:51-60, 1302-1373) | OFI/display changes are quote proxies; signed prints are aggressor flow only when feed qualifies. |
| S5 crowding/reversal | S4 signed flow/response and displayed liquidity with funding, OI, liquidation, confirmed bars (src/atlas/v2/runtime/full_strategy_surface.py:782-935; strategies/s5_crowding.py:327-505) | Qualified S4 and evidence refs; funding alone forbidden; requires exhaustion plus reclaim or flow reversal (full_strategy_surface.py:805-837; s5_crowding.py:480-505) | Research context | Does not prove liquidation causality or profitable exhaustion. |
| S6 BTC-adjusted relative strength | 720 intersected H1 log returns; per-asset BTC beta/residual volatility; sum latest 4 residuals / hourly sigma; own 50 contiguous H4 EMA context; top/bottom decile (src/atlas/v2/strategies/s6_cross_section.py:98-124, 767-824, 905-1000) | Exact timestamp intersection; latest returns contiguous; current liquidity/funding; separate H1 stop/M15 trigger/BBO/event contract (:132-190) | Research rank plus shadow single action (:431-735, 826-1055) | Rank statistic, not net-return forecast; beta is not a validated stable hedge. |
| S7 event reaction | Event calendar and M5/M15 response/beta/spread, not indicator-only (src/atlas/v2/runtime/full_strategy_surface.py:1408-1540, 1926-1949) | Event overflow blocks directional inference; freshness/source health | Research/event context | No demonstrated causal event effect or edge. |
| S8 pair spread | 721 synchronized hourly log-price levels; OLS alpha/beta/residual z; beta frozen at cutoff (src/atlas/v2/strategies/s8_pairs.py:234-284) | Complete 30d hourly prefix, exact pair and both-leg evidence (:238-255, 271-280) | Research basket only; no CandidateAction/plan permission (src/atlas/v2/runtime/full_strategy_surface.py:1985-2117) | OLS residual alone is not cointegration/stationarity or half-life; economic status NOT_ESTIMABLE pending execution/outcomes (s8_pairs.py:271-284). |

## Input-to-consumer trace

CausalBarStoreV2.as_of → asof_join (contract revision/cutoff/source health) → feature_snapshot (technical, candle, structure) → S1/S2/S3 and S6 policy consumers → CandidateAction/OpportunityWatch → downstream selection/economics. Separate market-quality path: captured raw L2/trades → SequenceValidBookV2 plus trade coverage → S4FeatureArtifactV2 → S4/S5 context and S7 diagnostics. S6 separately uses H1/H4, liquidity and funding. S8 emits research basket only. Inputs generally bind full instrument revisions and cutoffs; F1 is the regular-bar coverage exception.

## Independent second review of strategy entry prerequisites/signals

S1/S2/S3/S6 prerequisites combine completed bars, cutoff visibility, freshness/source health, universe/event checks and an explicit trigger; they produce shadow artifacts, not orders. These gates do not confer economic qualification. S2 candle volume is not flow. S3 is genuinely trade-at-price but production completeness is false. S4 trade flow differs from BBO OFI. S6 rank is not forecast probability. S8 is not economically estimable. F1/F2 mean sample count and cutoff do not imply full calendar coverage. No outcome dataset or signal edge was evaluated here.

## External definitions and endpoints

## External-method research status — BLOCKED BY ENVIRONMENT

The outbound documentation tunnel returned HTTP 403 for all read-only public-reference requests on 2026-10-13 UTC. The URLs below are research pointers required by the audit prompt, **not retrieved evidence**. I make no claim here about their current page contents. This leaves external methodology review incomplete; code-path distinctions above remain repository evidence only.

| Dated public reference pointer | Intended question | Retrieval and evidence limit |
|---|---|---|
| TradingView, [Volume Profile indicators: basic concepts](https://www.tradingview.com/support/solutions/43000502040-volume-profile-indicators-basic-concepts/) | How the platform describes its volume-profile bins/POC/value area, and how its bar-based estimates differ from exchange trade-at-price prints | Not retrieved; cannot validate the current methodology text. Any platform histogram still must not be represented as true trade-at-price without print-level data. |
| Binance USDⓈ-M REST [Kline/Candlestick Data](https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Kline-Candlestick-Data), [Aggregate Trades](https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Aggregate-Trades-List), and [Order Book](https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Order-Book) | Exchange-defined bar, aggregate trade, and displayed-depth response fields | Not retrieved; URL pointers do not prove adapter correctness, full capture, availability time, queue position, or live continuity. |
| Bybit V5 [Recent Public Trades](https://bybit-exchange.github.io/docs/v5/market/recent-trade) | Provider-specific recent trade schema/side semantics | Not retrieved; no claim about retention, completeness, or execution quality. |
| Park & Irwin (2007), [What Do We Know About the Profitability of Technical Analysis?](https://doi.org/10.1111/j.1467-6419.2007.00519.x) | Literature review of methodological and empirical claims for technical trading rules | DOI URL not retrieved; no claim about the paper’s conclusions is used in this audit. |

No market endpoint or external model provider was called. The audit therefore does not meet the prompt’s external-method research criterion. Validate primary exchange docs and independent methodological literature in a later environment with reachable public references before relying on exchange sequencing semantics or trading-concept definitions.

## Source snapshot read receipts and coverage

Snapshot contains 22 Markdown files plus MANIFEST.json. All 22 present Markdown files were read in full, individually and end-to-end; MANIFEST.json was also read in full. SHA-256 and byte counts for every present Markdown file match MANIFEST.json (22/22; zero mismatches). The user waived only the two absent Markdown files: 01_CHATGPT_PROJECT_INSTRUCTIONS_COPY_PASTE.md and 02_NEW_PROJECT_FIRST_CHAT_KICKOFF.md. Coverage is **22/24 Markdown files; 2/24 absent**. The per-file table below records the full-read receipt and verified digest. Neither absent file is claimed as reviewed.

| File | Bytes | Lines | SHA-256 |
|---|---:|---:|---|
| 00_START_HERE.md | 4860 | 35 | 1901f20a0f7b3f229b114b316ea83f32e78d7bcab681cf126fcd6be9ea44dff7 |
| 04_ATLAS_ENGINEERING_EXECUTION_RUNBOOK.md | 61469 | 437 | 8be2363d39f91fe796ac6d84bc066dcc0dfc3e70cdb628d6630bac4e321535b6 |
| ADR-001_Binance_Causal_Market_Data_Linux.md | 12263 | 69 | 23718723d44c2f4211a21078e848a09934a09d01857fb4922d945024dfa6972b |
| ADR-002_Agent_Opportunity_Decision.md | 23444 | 122 | 2d80ac6dd939f8dfb92ea3da6b547bc92fdd840ab069aabceacbbda100156bb5 |
| ADR-003_Position_Protection_Lifecycle.md | 18276 | 110 | 17150dd4f3b3fb85a056aa2600597bcdd317fc4338adeff90bfbb8d4f6d2715f |
| ADR-004_Mature_Libraries_Pretrained_ML.md | 17495 | 90 | 2fb5b4c78e8d6ab843daffccaa728eb253a1918070e41234e58ed9a84683036a |
| ADR-005_Independent_Quantitative_Trade_Assessment.md | 12653 | 76 | 1f7a33f5cebec5310941a4ff0637232586bf6bef15ba4f6ec213ed78d79e22ca |
| ADR-006_Agent_Initiated_Trading_Analysis_Tools.md | 17401 | 103 | 900a81459448fea2883097d4f650cf231e6fe863d92d5cefad13e3f34912b53d |
| ADR-007_Durable_Trading_Opportunity_And_Analysis_Memory.md | 18982 | 137 | 747a8ec425efa445771b46faddc0b118f237626bcc2c2a094dc422ac478a09b4 |
| ADR-008_Event_Driven_LLM_Vision_Cost_And_Bandwidth.md | 25631 | 112 | 6206c23e038bd9f8f1273be6e8ea4f7823fbcf65f331fa04a62eb2560cfeb2ae |
| ADR-009_Capital_Aware_Discovery_And_Manual_Control.md | 6980 | 44 | 1adff9b89b91f3f4e625622395ac42a0b5e9194ebe9c0728e8d026b942f4dc83 |
| ADR-010_Cached_Cross_Coin_Relationships_And_Peer_Context.md | 5691 | 37 | b47474f750bc6b03571f799a7fd819e1cb31249ce840306d05d139ae3501bca8 |
| ADR-011_Chart_Vision_Provider_And_Artifact_Contract.md | 6084 | 38 | 90c5f143b477372aef34ecd51d363a2268ee3e28b246734b6d09a030972ae7ad |
| ATLAS_AGENT_INTELLIGENCE_EXTENSION_FREEZE_V1.md | 11288 | 221 | d3e7b0b3da8a2a776db5dd05c656dbc5f04f3d8b1dfaaaec3fbd66966931682d |
| ATLAS_DESIGN_SIGNOFF_AND_OPEN_GATES.md | 11071 | 59 | 65d277ff2640b6d4ac0e5fbb688356d1cd7632c5bbc880624be71547f84b36b8 |
| ATLAS_FINAL_IMPLEMENTATION_CLARIFICATION_AND_V1_FREEZE_COMPLETED.md | 100689 | 1111 | c13cad1ba2f3f8c250d55099017770f5144c6cfd71be4bee1e65c5f075806a5c |
| ATLAS_FINAL_TARGET_DESIGN_LOCK_2026-10-12.md | 4322 | 24 | debe11c6cb0763eaed7e7d628e3dd6260635e6edaaa4a9cab39a4273be5b3265 |
| ATLAS_OWNER_DECISIONS_AGENT_AUTHORITY_DISCOVERY_ALTCOINS_2026-10-12.md | 17182 | 70 | d323030cebc6d8d17d6401765ed49c250548e2fa9ab57e074933cf364bcb8c92 |
| ATLAS_TRANSITION_ADVERSARIAL_DESIGN_REVIEW.md | 24602 | 156 | 8c1400e5972a75612e6586ddd338f0a8eceab7ac8ec65ab6eb359916627b08f8 |
| ATLAS_TRANSITION_ARCHITECTURE_DESIGN_V1.md | 52277 | 258 | 2a5735ee29c73c079744f96504a0fe7e5cff86c81a8a2de7766b5974d75e1dfe |
| ATLAS_TRANSITION_FREEZE_TRACE_AND_APPROVAL.md | 15606 | 97 | 21fdbfe8b076209cc3eb1bdc7f1f9863c416157662350ff2d6ed81b4291c9448 |
| ATLAS_V2_FINAL_INTRADAY_INTELLIGENCE_IMPLEMENTATION_FREEZE_AMENDED_2026-09-25.md | 88134 | 3599 | e868e3e25230fb7fe334e769949bd0d8892edcf66804b0b773cd37ebb2d8fe78 |
| MANIFEST.json | 7665 | 200 | 447dbfc8219b943c693b141767e14f494272f73380b9acbc4a99c1a121e668b1 |
