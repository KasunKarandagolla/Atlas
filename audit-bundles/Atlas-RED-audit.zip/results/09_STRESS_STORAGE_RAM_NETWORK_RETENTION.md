# Stress, resource, network, storage, and retention evidence

**Status: INCOMPLETE / NOT ESTIMABLE for sustained operation.** This audit ran no tests or stress probes. It read the pinned S49 handoff and reports, and measured only the current Cloud Codex host metadata. The existing test evidence is from prior S49 processes and cannot be transferred to the owner’s target device or treated as a 24-hour production profile.

## What was measured in this audit

| Metric | Audit observation | Meaning and limit |
|---|---|---|
| Cloud host | Linux x86_64; kernel `6.18.44`; CPython 3.12.14; 5 visible CPUs; 33 GiB RAM; no swap | Current Cloud Codex runner only; not owner hardware or a modest Linux qualification |
| `/tmp` filesystem | 17,871,892,480 bytes total; 52,678,656 bytes used at snapshot | Disposable audit storage, not Atlas production retention |
| Existing environment | `/workspace/.venvs/atlas/bin/python` is Python 3.12.14; installed `atlas 0.1.0` is editable from `/workspace/Atlas` | Does not establish dependency lock/readiness on the audit SHA |
| Mounted checkout | `/workspace/Atlas`, branch `work`, HEAD `bac8b16e767e7a253cc41c4e73f16ac1c6658319`; clean | Stale Session 001 checkout. The actual audit uses a separate clean clone pinned to S49 under `/tmp` |
| Setup configuration draft | Install draft points to `/workspace/Atlas` and creates/reuses `/workspace/.venvs/atlas`, then installs `.[dev]`; start draft points at the Session 001 checkout and invokes broad pytest/Ruff/mypy checks | Inspected, not executed or changed. Package installation and full tests would violate this audit’s read-only, bounded-resource scope |
| Audit writes to Atlas | None | All reports and the generated AST CSV are under the disposable `/tmp/atlas_readonly_audit_a73c92d83ca8/results/` tree |
| Network | Zero market-data downloads and zero exchange/provider calls | GitHub branch/commit metadata may be queried as read-only preflight; it is not market data |

## Historical S49 process evidence (not rerun)

| Workload | Reported result | Reported write/RAM evidence | Qualification |
|---|---|---|---|
| Source/features/strategies group | 237/238 passing in 38m 03s; 4,096-product/three-cycle archive/restart subcase passed in 28m 08s | 7,037,568 filesystem-output blocks at 512 bytes/block ≈ **3,603,234,816 bytes (3.60 GB)**; 789,296 KiB peak RSS | One test process’s write accounting, not net retained disk growth, leak rate, or ordinary production rate. About 72% of the 5,000,000,000-byte daily ceiling in that one group if charged to the budget. |
| Bounded mixed 1,024-contract stream/report workload | `test_mixed_1024_contract_public_workload_under_bounded_stalls` failed in the group and when isolated; queue high-water 480/512; one frame rejected; overflow recorded | Isolated test peak RSS about 170,000 KiB | Actual bounded synthetic failure from S49 evidence; not reproduced in this audit. Do not raise queue limits or suppress its loss latch. |
| Broader repository suite | Stopped at 1,196/2,783; 1,185 passed, 6 partial failures, 5 skipped; full suite incomplete | 996,196 KiB peak RSS; 3,222,856 filesystem-output blocks ≈ **1,650,102,272 bytes (1.65 GB)** | Separate partial run; not a completed suite, and output blocks are not retained bytes. |
| Historical evidence aggregate | If the two process-output figures above fell within the same 24-hour window, they total about **5.25 GB**, above the 5.00 GB cap | Exact process timestamps/cumulative accounting window were not available for independent reconciliation here | This is a conditional cap-risk indicator, not a claim that a verified 24-hour counter exceeded the limit. The source workload alone already consumes most of the cap. |
| Source service injected short stall | One 1-second injected stall test passed; 1.023 s observed against 1.201 s bound | No broad input rate or endurance measurement | Narrow control check only; no queue headroom, sustained drain, or live-source claim |
| Persistence test | 4,096 products, three cycles, 384 archive pages, restart equality checks passed inside source group | 28m 08s; aggregate source group I/O above | No live streams, full decision/feature lane at that breadth, or daily storage growth |

The S49 report counts the broader suite as 2,783 collected tests across 279 files but stopped during a long S3 fixture. It records six partial failures and five skips without a final JUnit summary. Some mapped failures were retained environment gates; the source group’s one mixed-capacity assertion remains a reproducible failure. None was repaired or rerun here.

## RAM, disk, and network conclusions

- **RAM:** historical peaks are about 771 MiB for the 38-minute selected group and 973 MiB for the interrupted broad group. A peak is not evidence of a leak. No time-series RSS, process-tree aggregation, Python heap, cache occupancy, GUI-plus-worker total, owner-device baseline, or 24-hour drift was measured. Whole-product RAM remains **NOT ESTIMABLE**.
- **Disk retained:** production run roots, SQLite/WAL, capture archives, reports, and histories have durable consumers. S49 reports inventory/capture byte telemetry and a disk-reserve shutdown, but no retention/endurance proof. Net retained bytes and growth per hour/day are **NOT ESTIMABLE**.
- **Disk writes/churn:** one S49 group reported 3.60 GB of filesystem output, and a separate incomplete run reported 1.65 GB. The output accounting includes writes later removed or rewritten and must not be called retained size. Do not rerun the broad group within a 24-hour window without a measured quota plan; its recorded write intensity risks the owner’s cap.
- **Network:** no public market-data archive or exchange/provider endpoint was contacted for this review; market-data bytes and requests are zero. Git repository metadata checks do not qualify a data-source network budget. Provider prompt/image egress and actual source rates remain unmeasured.

## Retention proposal for the next authorized engineering task

This is a design proposal, not implemented cleanup. Preserve anything needed to prove current exposure, restore after restart, explain a decision, or reproduce a matured outcome. Apply expiry only after ownership/reference checks and a grace interval are recorded.

| Data class | Retention treatment | Evidence needed before deletion/compaction |
|---|---|---|
| Active position, entry/exit intent, reservation, fills, stop/protection readback, cash/funding reconciliation, UNKNOWN or ambiguous send | Keep durably until independently reconciled flat, all related work terminal, and required audit/maturity references complete | Restart/recovery test proving no loss, duplicate, false flatness, or orphaned protection |
| Decision/candidate/calendar, source receipt, actual/reconstructed timing, accepted risk/action/economic artifacts, matured outcome | Preserve immutable identity and all referenced source/economic inputs for the approved replay/audit horizon; terminal state is not a deletion signal | Reference-count/version audit; reproducible replay and export/backup verification |
| Raw trades/book/bars and Parquet/archive blocks | Retain blocks referenced by open risk, pending work, outcomes, disputed decisions, or required scientific replay. Consider policy-versioned compaction only for unreferenced low-value high-frequency data | Exact source/consumer ref graph, revision/hash retention, gap/sequence evidence, lifecycle grace period, and restart/rollback test |
| SQLite WAL/journals and migrations | Keep transactionally consistent; checkpoint only through supported SQLite lifecycle. Do not delete WAL/SHM files while DB may be open | WAL high-water/checkpoint/drain measure under mixed writes, crash/reopen integrity, byte accounting |
| Expired watches, due jobs, provider/agent ledger, event and error history | Expire work state by explicit terminal transitions; compact records only when no dependent candidate, decision, outcome, or incident refers to them | Durable cleanup receipt with dependency check, version, reason, and before/after bytes |
| Derived indicators, bounded feature caches, temporary report artifacts | Bound by size/TTL and last consumer; remove scratch only after atomic publication/process exit and no open handle | Cache occupancy/refcount, deletion-grace test, crash/restart and rollback test |
| Future prompts/images/model outputs and downloaded model artifacts | Not active in production flow or this audit; default to no persistent copy unless owner approves a specific evidence purpose | Per-job/day bytes and spend ceilings, PII/secret exclusion, lineage, TTL and deletion record |

No per-category safe numeric retention horizon or projected GiB/day is evidence-backed today; each remains **NOT ESTIMABLE**. The smallest qualification should first instrument one declared low-resource Linux profile under equivalent feature deadlines, capture+report concurrency, bounded burst/recovery, WAL/archive geometry, GUI/worker aggregation, and a full drain, with per-process and aggregate write counters and automatic stop well below 5,000,000,000 bytes/24h. Keep queue thresholds and loss detection intact.
